<?php
declare(strict_types=1);

// Validasi login
if (!function_exists('require_login')) {
    function require_login(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: login.php');
            exit;
        }
    }
}

// Alias untuk kompatibilitas camelCase
if (!function_exists('requireLogin')) {
    function requireLogin(): void
    {
        require_login();
    }
}

function require_role(array $roles): void
{
    require_login();

    if (!in_array($_SESSION['user']['role'] ?? '', $roles, true)) {
        json_response([
            'success' => false,
            'message' => 'Akses ditolak.'
        ], 403);
    }
}

function json_response(array $data,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function e(string $s):string{return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}
function csrf_token():string{if(empty($_SESSION['_csrf']))$_SESSION['_csrf']=bin2hex(random_bytes(32));return $_SESSION['_csrf'];}
function csrf_require():void{$sent=$_SERVER['HTTP_X_CSRF_TOKEN']??($_POST['_csrf']??'');if(!is_string($sent)||!hash_equals(csrf_token(),$sent))json_response(['success'=>false,'message'=>'Sesi keamanan tidak valid. Muat ulang halaman dan coba kembali.'],419);}
function audit_log(PDO $db,string $action,string $entity,?int $entityId=null,array $details=[]):void{try{$q=$db->prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details,ip_address,user_agent) VALUES(?,?,?,?,?,?,?)');$q->execute([$_SESSION['user']['id']??null,$action,$entity,$entityId,json_encode($details,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),substr($_SERVER['REMOTE_ADDR']??'',0,45),substr($_SERVER['HTTP_USER_AGENT']??'',0,255)]);}catch(Throwable $e){error_log('BARAKKA audit log: '.$e->getMessage());}}
function json_input():array{$raw=file_get_contents('php://input');$data=json_decode($raw,true);return is_array($data)?$data:[];}
