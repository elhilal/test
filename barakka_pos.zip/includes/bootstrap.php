<?php
declare(strict_types=1);

// Konfigurasi keamanan session
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');

$isHttps = (
    !empty($_SERVER['HTTPS']) &&
    $_SERVER['HTTPS'] !== 'off'
);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

// Load fungsi autentikasi
require_once __DIR__ . '/auth.php';

// Load koneksi database jika belum dimuat
// Pertahankan konfigurasi database yang sudah ada.

// Load koneksi database jika belum dimuat
// Pertahankan konfigurasi database yang sudah ada.
require_once __DIR__ . '/../config/database.php';

// Inisialisasi koneksi PDO
if (!isset($db) || !($db instanceof PDO)) {
    $db = Database::connection();
}