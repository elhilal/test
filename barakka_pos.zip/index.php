<?php
require_once __DIR__ . '/includes/bootstrap.php';
requireLogin();
$me = $_SESSION['user'];
$role = $me['role'];
$roleLabels=['OWNER'=>'Pemilik','KASIR'=>'Kasir','CHEF'=>'Koki','KARYAWAN'=>'Karyawan'];
$roleLabel=$roleLabels[$role]??$role;
if($role==='CHEF'){header('Location: kitchen.php');exit;}
$isOwner=$role==='OWNER';
$canCashier=in_array($role,['OWNER','KASIR'],true);
$canReports=in_array($role,['OWNER','KASIR'],true);
$canOrder=in_array($role,['OWNER','KASIR','KARYAWAN'],true);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?=e(csrf_token())?>"><meta name="theme-color" content="#F5A900">
<link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="assets/icons/barakka.svg" type="image/svg+xml">
<title><?= $isOwner?'Dashboard Pemilik':($role==='KARYAWAN'?'Dashboard Karyawan':'Dashboard Kasir') ?> | BARAKKA POS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg topbar sticky-top"><div class="container-fluid px-lg-4">
<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php"><span class="brand-mark-sm">B</span><span>BARAKKA <small class="brand-subtitle">POS · Dapur Rasa</small></span></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-label="Buka navigasi"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="mainNav"><div class="navbar-nav me-auto">
<a class="nav-link active" href="index.php">Dashboard</a>
<?php if($canOrder):?><a class="nav-link" href="order-entry.php">Buat Pesanan</a><?php endif;?>
<?php if($canCashier):?><a class="nav-link" href="#orders">Daftar Order</a><a class="nav-link" href="stock.php">Stok Harian</a><?php endif;?>
<?php if($isOwner):?><a class="nav-link" href="menus.php">Menu & Harga</a><?php endif;?><?php if($canReports):?><a class="nav-link" href="#reports">Laporan</a><?php endif;?><?php if($isOwner):?><a class="nav-link" href="users.php">Pengguna</a><a class="nav-link" href="audit.php">Audit Log</a><?php endif;?>
</div><div class="d-flex align-items-center gap-3 py-2"><span class="small fw-semibold"><?=e($me['name'])?> <span class="role-chip"><?=e($roleLabel)?></span></span><a href="logout.php" class="btn btn-outline-dark btn-sm">Keluar</a></div></div>
</div></nav>
<main class="container-fluid px-3 px-lg-4 py-4">
<header class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4"><div><div class="eyebrow">BARAKKA · DAPUR RASA</div><h1 class="h3 fw-bold mb-1"><?= $isOwner?'Dashboard Pemilik':($role==='KARYAWAN'?'Dashboard Karyawan':'Dashboard Kasir') ?></h1><div class="text-secondary"><?= $isOwner?'Pantau penjualan dan seluruh kegiatan operasional BARAKKA.':($role==='KARYAWAN'?'Akses cepat untuk membantu pencatatan pesanan pelanggan.':'Kelola pesanan pelanggan dan aktivitas kasir hari ini.') ?></div></div><div id="todayLabel" class="date-chip"></div></header>
<?php if($role!=='KARYAWAN'):?><div class="row g-3 mb-4">
<div class="col-6 col-xl-3"><div class="stat-card stat-orders"><small>Total pesanan hari ini</small><div class="stat-value" id="statOrders">--</div><span class="stat-caption">Semua jenis pesanan</span></div></div>
<div class="col-6 col-xl-3"><div class="stat-card stat-pending"><small>Menunggu persetujuan</small><div class="stat-value" id="statPending">--</div><span class="stat-caption">Perlu ditindaklanjuti</span></div></div>
<div class="col-6 col-xl-3"><div class="stat-card stat-preparing"><small>Sedang diproses</small><div class="stat-value" id="statPreparing">--</div><span class="stat-caption">Antrean operasional</span></div></div>
<div class="col-6 col-xl-3"><div class="stat-card stat-sales"><small>Penjualan dibayar hari ini</small><div class="stat-value" id="statSales">--</div><span class="stat-caption">Akumulasi pembayaran masuk</span></div></div>
</div><?php else:?><section class="staff-welcome mb-4"><div><span class="eyebrow">BARAKKA · DAPUR RASA</span><h2 class="h4 fw-bold mb-1">Selamat bertugas, <?=e($me['name'])?>!</h2><p class="mb-0">Gunakan menu Buat Pesanan untuk mencatat pesanan pelanggan.</p></div><a href="order-entry.php" class="btn btn-brand btn-lg">＋ Buat Pesanan</a></section><?php endif;?>
<section class="panel p-3 mb-4"><div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2"><div><h2 class="h6 fw-bold mb-1">Akses cepat</h2><small class="text-secondary">Pilih pekerjaan yang ingin dilakukan.</small></div></div><div class="quick-actions">
<?php if($canOrder):?><a class="quick-action quick-red" href="order-entry.php"><span class="quick-icon">＋</span><span><b>Buat Pesanan</b><small>Input order pelanggan</small></span></a><?php endif;?>
<?php if($canCashier):?><a class="quick-action" href="#orders"><span class="quick-icon">☷</span><span><b>Daftar Order</b><small>Persetujuan & pembayaran</small></span></a><a class="quick-action" href="stock.php"><span class="quick-icon">▦</span><span><b>Stok Harian</b><small>Atur ketersediaan menu</small></span></a><a class="quick-action" href="qr.php"><span class="quick-icon">▧</span><span><b>QR Code Meja</b><small>QR pemesanan pelanggan</small></span></a><?php endif;?>
<?php if($isOwner):?><a class="quick-action" href="menus.php"><span class="quick-icon">🍽</span><span><b>Menu & Harga</b><small>Kelola katalog dan foto</small></span></a><a class="quick-action" href="users.php"><span class="quick-icon">♙</span><span><b>Pengguna</b><small>Kelola hak akses</small></span></a><?php endif;?>
<a class="quick-action" href="customer.php" target="_blank"><span class="quick-icon">↗</span><span><b>Halaman Pelanggan</b><small>Buka katalog pemesanan</small></span></a>
</div></section>
<div class="row g-4">
<?php if($canCashier):?>
<div class="col-xl-7" id="orders"><section class="panel h-100"><div class="panel-head"><div><h2 class="h5 fw-bold mb-0">Daftar pesanan terbaru</h2><small class="text-secondary">Pesanan dari pelanggan dan input karyawan</small></div><span class="live-dot">LANGSUNG</span></div><div class="p-3" id="orderList">Memuat pesanan...</div></section></div>
<div class="col-xl-5" id="stock"><section class="panel h-100"><div class="panel-head"><div><h2 class="h5 fw-bold mb-0">Ketersediaan stok hari ini</h2><small class="text-secondary">Stok tersedia dan dipesan</small></div><a href="stock.php" class="small fw-bold">Kelola</a></div><div class="p-3" id="stockList">Memuat stok...</div></section></div>
<?php endif;?>
<?php if($canReports):?>
<div class="col-12" id="reports"><section class="panel"><div class="panel-head"><div><h2 class="h5 fw-bold mb-0">Laporan penjualan</h2><small class="text-secondary">Pantau performa penjualan BARAKKA</small></div></div><div class="p-3"><div class="row g-3 align-items-end"><div class="col-12 col-sm-4 col-lg-3"><label class="form-label fw-semibold" for="reportPeriod">Periode laporan</label><select id="reportPeriod" class="form-select"><option value="daily">Harian</option><option value="weekly">Mingguan</option><option value="monthly">Bulanan</option></select></div><div class="col-12 col-sm-4 col-lg-3"><label class="form-label fw-semibold" for="reportDate">Tanggal acuan</label><input id="reportDate" type="date" class="form-control"></div><div class="col-12 col-sm-4 col-lg-2"><button id="loadReport" class="btn btn-brand w-100">Tampilkan</button></div><div class="col-12 col-lg-4 text-lg-end"><button id="exportCsv" class="btn btn-outline-success w-100">Unduh Excel (XLSX)</button></div></div><div id="reportOutput" class="mt-4 text-secondary small">Pilih periode dan tanggal laporan.</div></div></section></div>
<div class="col-12"><section class="panel p-3"><div class="d-flex justify-content-between flex-wrap gap-2 align-items-center"><div><h2 class="h6 fw-bold mb-1">Tautan pemesanan pelanggan</h2><small class="text-secondary">Bagikan link ini atau cetak QR Code di setiap meja.</small></div><a class="btn btn-brand" href="qr.php">Kelola QR Code</a></div><div class="small mt-2"><code id="customerUrl"></code></div></section></div>
<?php endif;?>
</div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if($canCashier):?><script src="assets/js/dashboard.js"></script><?php endif;?>
<?php if($canReports):?><script src="assets/js/reports.js"></script><script>document.getElementById('customerUrl').textContent=location.origin+location.pathname.replace(/index\.php$/,'')+'customer.php';</script><?php endif;?>
<script>if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});</script>
</body></html>
