# BARAKKA POS — Pemeriksaan dan Penyempurnaan 5 November 2026

## Yang diperiksa
- Halaman customer tanpa login, API katalog publik, API order publik, dan halaman tracking.
- Login, session, role access, dashboard, API order, pembayaran, stok, laporan, ekspor XLSX.
- Kitchen Display, alur persetujuan, konsumsi/reservasi stok, timer, dan logout.
- Seluruh file PHP diperiksa dengan `php -l`; file JavaScript utama diperiksa dengan `node --check`.

## Perubahan pada paket ini
1. Kitchen Display sekarang memiliki tombol Logout.
2. Koki memilih estimasi pengerjaan saat mulai memasak (5/10/15/20/30/45/60 menit).
3. Timer KDS menghitung mundur dari `started_at + estimated_minutes`; bila lewat target akan menampilkan `Terlambat`.
4. Pesanan yang disetujui Owner/Kasir/Chef kini menahan stok dengan status `RESERVED`. Timer dan pemakaian stok baru dimulai saat Koki menekan `Mulai memasak`. Ini menyamakan alur pesanan langsung dan Pre-Order sehingga waktu memasak tidak terhitung sejak kasir menyetujui pesanan.
5. Estimasi disimpan di tabel `orders`, sehingga tetap benar setelah refresh.
6. Endpoint daftar order dan ringkasan dashboard dibatasi untuk OWNER/KASIR.
7. Tabel `audit_logs` disertakan juga pada schema instalasi baru.
8. Dashboard JS tidak lagi error bila elemen panel dapur opsional tidak tersedia.

## Instalasi update pada database lama
1. Backup database `barakka_pos` terlebih dahulu.
2. Pastikan migration sebelumnya `database/migration_20261101_hardening.sql` sudah dijalankan.
3. Jalankan `database/migration_20261105_kitchen_timer.sql` melalui phpMyAdmin > SQL.
4. Timpa file aplikasi dengan isi paket update ini. Jangan import ulang `database/schema.sql` pada database yang sudah berisi data.
5. Restart Apache, lalu hard refresh browser (Ctrl+F5).

## Instalasi baru
Import `database/schema.sql` saja. Schema baru sudah mencakup `estimated_minutes` dan `audit_logs`; migration 20261105 tidak perlu dijalankan.

## Catatan pengujian
Pemeriksaan statis PHP dan JavaScript berhasil. Koneksi database MySQL, transaksi stok, pembayaran, dan browser belum dapat diuji end-to-end karena tidak tersedia database BARAKKA milik pengguna di lingkungan pemeriksaan. Lakukan uji transaksi di database salinan sebelum digunakan operasional.
