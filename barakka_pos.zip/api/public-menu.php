<?php
require_once __DIR__.'/../includes/bootstrap.php';
$date=trim($_GET['date']??date('Y-m-d')); if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) $date=date('Y-m-d');
$q=$db->prepare("SELECT m.menu_id,m.menu_name,m.description,m.category,m.unit_name,m.price,m.image_path,COALESCE(s.available_qty,0) available_qty FROM menus m LEFT JOIN daily_stocks s ON s.menu_id=m.menu_id AND s.stock_date=? WHERE m.is_active=1 ORDER BY m.category,m.menu_name");
$q->execute([$date]); json_response(['success'=>true,'date'=>$date,'data'=>$q->fetchAll()]);
