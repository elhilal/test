<?php
require_once __DIR__.'/../includes/bootstrap.php';require_role(['OWNER','KASIR']);
$q=$db->prepare("SELECT COUNT(*) total_orders,SUM(status='PENDING') pending_orders,SUM(status IN('RESERVED','PREPARING')) preparing_orders FROM orders WHERE DATE(created_at)=CURDATE()");$q->execute();$counts=$q->fetch()?:[];
$q=$db->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status='PAID' AND DATE(paid_at)=CURDATE()");$q->execute();
json_response(['success'=>true,'counts'=>$counts,'sales'=>(float)$q->fetchColumn()]);
