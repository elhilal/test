<?php
require_once __DIR__.'/../includes/bootstrap.php';require_login();
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['success'=>false,'message'=>'Method not allowed'],405);csrf_require();
$in=json_decode(file_get_contents('php://input'),true)??[];$id=filter_var($in['order_id']??null,FILTER_VALIDATE_INT);$action=$in['action']??'';$estimate=filter_var($in['estimated_minutes']??15,FILTER_VALIDATE_INT);
if(!$id||!in_array($action,['approve','start','complete','cancel','reject'],true))json_response(['success'=>false,'message'=>'Input tidak valid.'],422);
$role=$_SESSION['user']['role'];
$permissions=['approve'=>['OWNER','KASIR','CHEF'],'start'=>['OWNER','CHEF'],'complete'=>['OWNER','CHEF'],'cancel'=>['OWNER','KASIR'],'reject'=>['OWNER','KASIR','CHEF']];
if($action==='start' && (!$estimate || $estimate<1 || $estimate>180)) json_response(['success'=>false,'message'=>'Estimasi pengerjaan harus 1 sampai 180 menit.'],422);
if(!in_array($role,$permissions[$action],true))json_response(['success'=>false,'message'=>'Role tidak memiliki akses untuk aksi ini.'],403);
try{
 $db->beginTransaction();$q=$db->prepare("SELECT * FROM orders WHERE order_id=? FOR UPDATE");$q->execute([$id]);$o=$q->fetch();if(!$o)throw new RuntimeException('Pesanan tidak ditemukan.');
 if($action==='approve'){
  if($o['status']!=='PENDING')throw new RuntimeException('Pesanan bukan Pending.');
  $d=$db->prepare("SELECT menu_id,qty FROM order_details WHERE order_id=? ORDER BY menu_id");$d->execute([$id]);$items=$d->fetchAll();
  foreach($items as $it){$s=$db->prepare("SELECT stock_id,available_qty FROM daily_stocks WHERE menu_id=? AND stock_date=? FOR UPDATE");$s->execute([$it['menu_id'],$o['stock_date']]);$stockRow=$s->fetch();$avail=$stockRow['available_qty']??false;if($avail===false||(int)$avail<(int)$it['qty'])throw new RuntimeException('Stok tersedia tidak mencukupi.');}
  $up=$db->prepare("UPDATE daily_stocks SET available_qty=available_qty-?,reserved_qty=reserved_qty+? WHERE menu_id=? AND stock_date=? AND available_qty>=?");
  foreach($items as $it){$up->execute([$it['qty'],$it['qty'],$it['menu_id'],$o['stock_date'],$it['qty']]);if($up->rowCount()!==1)throw new RuntimeException('Gagal mengunci stok.');}
  // Semua pesanan yang disetujui menahan stok terlebih dahulu.
  // Timer baru dimulai saat Koki menekan Mulai Memasak.
  $new='RESERVED';
  $m=$db->prepare("INSERT INTO stock_movements(stock_id,order_id,movement_type,qty,actor_user_id,note) SELECT stock_id,?,'RESERVE',?,?,? FROM daily_stocks WHERE menu_id=? AND stock_date=?");
  foreach($items as $it){$m->execute([$id,$it['qty'],$_SESSION['user']['id'],'Order approved; stock reserved',$it['menu_id'],$o['stock_date']]);}
  $u=$db->prepare("UPDATE orders SET status='RESERVED',reservation_state='HELD',started_at=NULL,accepted_by=? WHERE order_id=?");$u->execute([$_SESSION['user']['id'],$id]);
 }elseif($action==='start'){
  if($o['status']!=='RESERVED'||$o['reservation_state']!=='HELD')throw new RuntimeException('Pesanan belum di-reserve.');
  if($o['scheduled_at']&&strtotime($o['scheduled_at'])>time())throw new RuntimeException('Belum waktunya memulai Pre-Order.');
  $d=$db->prepare("SELECT menu_id,qty FROM order_details WHERE order_id=? ORDER BY menu_id");$d->execute([$id]);$items=$d->fetchAll();
  foreach($items as $it){$u=$db->prepare("UPDATE daily_stocks SET reserved_qty=reserved_qty-?,used_qty=used_qty+? WHERE menu_id=? AND stock_date=DATE(?) AND reserved_qty>=?");$u->execute([$it['qty'],$it['qty'],$it['menu_id'],$o['stock_date'],$it['qty']]);if($u->rowCount()!==1)throw new RuntimeException('Data reservasi stok tidak konsisten.');}
  $m=$db->prepare("INSERT INTO stock_movements(stock_id,order_id,movement_type,qty,actor_user_id,note) SELECT stock_id,?,'CONSUME',?,?,? FROM daily_stocks WHERE menu_id=? AND stock_date=?");
  foreach($items as $it){$m->execute([$id,$it['qty'],$_SESSION['user']['id'],'Reserved pre-order moved to preparation',$it['menu_id'],$o['stock_date']]);}
  $u=$db->prepare("UPDATE orders SET status='PREPARING',reservation_state='CONSUMED',started_at=NOW(),estimated_minutes=? WHERE order_id=?");$u->execute([$estimate,$id]);
 }elseif($action==='complete'){
  if($o['status']!=='PREPARING')throw new RuntimeException('Pesanan belum dalam proses.');
  $u=$db->prepare("UPDATE orders SET status='COMPLETED',completed_at=NOW() WHERE order_id=?");$u->execute([$id]);
 }elseif($action==='reject'){
  if($o['status']!=='PENDING')throw new RuntimeException('Hanya pesanan Pending yang dapat ditolak.');
  $u=$db->prepare("UPDATE orders SET status='REJECTED' WHERE order_id=?");$u->execute([$id]);
 }else{
  if(!in_array($o['status'],['PENDING','RESERVED'],true))throw new RuntimeException('Pesanan yang sudah diproses tidak dapat dibatalkan dari menu ini.');
  if($o['status']==='RESERVED'&&$o['reservation_state']==='HELD'){
   $d=$db->prepare("SELECT menu_id,qty FROM order_details WHERE order_id=? ORDER BY menu_id");$d->execute([$id]);foreach($d->fetchAll() as $it){$u=$db->prepare("UPDATE daily_stocks SET available_qty=available_qty+?,reserved_qty=reserved_qty-? WHERE menu_id=? AND stock_date=DATE(?) AND reserved_qty>=?");$u->execute([$it['qty'],$it['qty'],$it['menu_id'],$o['stock_date'],$it['qty']]);if($u->rowCount()!==1)throw new RuntimeException('Gagal melepas reservasi.');$m=$db->prepare("INSERT INTO stock_movements(stock_id,order_id,movement_type,qty,actor_user_id,note) SELECT stock_id,?,'RELEASE',?,?,? FROM daily_stocks WHERE menu_id=? AND stock_date=?");$m->execute([$id,$it['qty'],$_SESSION['user']['id'],'Reservation released after cancellation',$it['menu_id'],$o['stock_date']]);}
   $state='RELEASED';
  }else{$state='NONE';}
  $u=$db->prepare("UPDATE orders SET status='CANCELLED',reservation_state=? WHERE order_id=?");$u->execute([$state,$id]);
 }
 $log=$db->prepare("INSERT INTO order_status_logs(order_id,old_status,new_status,actor_user_id) VALUES(?,?,?,?)");$log->execute([$id,$o['status'],$action==='approve'?'RESERVED':($action==='start'?'PREPARING':($action==='complete'?'COMPLETED':($action==='reject'?'REJECTED':'CANCELLED'))),$_SESSION['user']['id']]);
 audit_log($db,'ORDER_'.$action,'orders',$id,['old_status'=>$o['status'],'estimated_minutes'=>$action==='start'?$estimate:null]);$db->commit();json_response(['success'=>true,'message'=>'Status pesanan diperbarui.']);
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],409);}
