<?php
require_once __DIR__.'/../includes/bootstrap.php';require_login();
$q=$db->prepare("SELECT m.menu_id,m.menu_name,m.unit_name,m.price,COALESCE(s.initial_qty,0) initial_qty,COALESCE(s.available_qty,0) available_qty,COALESCE(s.reserved_qty,0) reserved_qty,COALESCE(s.used_qty,0) used_qty FROM menus m LEFT JOIN daily_stocks s ON s.menu_id=m.menu_id AND s.stock_date=CURDATE() WHERE m.is_active=1 ORDER BY m.menu_name");
$q->execute();json_response(['success'=>true,'data'=>$q->fetchAll()]);
