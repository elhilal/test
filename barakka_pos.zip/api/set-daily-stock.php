<?php
require_once __DIR__.'/../includes/bootstrap.php';require_role(['OWNER','KASIR']);
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['success'=>false,'message'=>'Method not allowed'],405);csrf_require();
$in=json_decode(file_get_contents('php://input'),true)??[];
$menuId=filter_var($in['menu_id']??null,FILTER_VALIDATE_INT);$qty=filter_var($in['initial_qty']??null,FILTER_VALIDATE_INT);$date=$in['stock_date']??date('Y-m-d');
if(!$menuId||$qty===false||$qty<0||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))json_response(['success'=>false,'message'=>'Menu, tanggal, atau jumlah stok tidak valid.'],422);
try{
 $db->beginTransaction();
 $q=$db->prepare("SELECT stock_id,reserved_qty,used_qty FROM daily_stocks WHERE menu_id=? AND stock_date=? FOR UPDATE");$q->execute([$menuId,$date]);$old=$q->fetch();
 if($old){
  if((int)$old['reserved_qty']>0||(int)$old['used_qty']>0)throw new RuntimeException('Stok tidak dapat diubah setelah ada reservasi atau pemakaian. Gunakan penyesuaian stok.');
  $q=$db->prepare("UPDATE daily_stocks SET initial_qty=?,available_qty=? WHERE stock_id=?");$q->execute([$qty,$qty,$old['stock_id']]);$stockId=(int)$old['stock_id'];$movement='ADJUSTMENT';
 }else{
  $q=$db->prepare("INSERT INTO daily_stocks(menu_id,stock_date,initial_qty,available_qty,reserved_qty,used_qty) VALUES(?,?,?, ?,0,0)");$q->execute([$menuId,$date,$qty,$qty]);$stockId=(int)$db->lastInsertId();$movement='OPENING';
 }
 $q=$db->prepare("INSERT INTO stock_movements(stock_id,movement_type,qty,actor_user_id,note) VALUES(?,?,?,?,?)");$q->execute([$stockId,$movement,$qty,$_SESSION['user']['id'],'Input stok harian']);
 audit_log($db,'STOCK_SET','daily_stocks',$stockId,['menu_id'=>$menuId,'date'=>$date,'quantity'=>$qty]);$db->commit();json_response(['success'=>true,'stock_id'=>$stockId]);
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],409);}
