<?php
require_once __DIR__.'/../includes/bootstrap.php';require_role(['OWNER','KASIR','KARYAWAN']);
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['success'=>false,'message'=>'Method not allowed'],405);csrf_require();
$in=json_decode(file_get_contents('php://input'),true)??[];
$name=trim($in['customer_name']??'');$type=$in['order_type']??'';$items=$in['items']??[];
$valid=['DINE_IN','TAKE_AWAY','GRAB','PRE_ORDER'];
if($name===''||!in_array($type,$valid,true)||!is_array($items)||!count($items)||count($items)>30)json_response(['success'=>false,'message'=>'Nama, jenis pesanan dan item wajib diisi.'],422);
$table=trim($in['table_or_seat']??'');$grab=trim($in['grab_reference']??'');$scheduled=$in['scheduled_at']??null;
if($type==='DINE_IN'&&$table==='')json_response(['success'=>false,'message'=>'Nama atau nomor meja/kursi wajib diisi untuk Dine In.'],422);
if($type==='GRAB'&&$grab==='')json_response(['success'=>false,'message'=>'Nomor order Grab wajib diisi.'],422);
if($type==='PRE_ORDER'&&(!$scheduled||strtotime($scheduled)===false||strtotime($scheduled)<=time()))json_response(['success'=>false,'message'=>'Jadwal Pre-Order harus berupa waktu di masa depan.'],422);
try{
 $db->beginTransaction();$ids=[];$total=0;
 foreach($items as $item){$mid=filter_var($item['menu_id']??null,FILTER_VALIDATE_INT);$qty=filter_var($item['qty']??null,FILTER_VALIDATE_INT);if(!$mid||!$qty||$qty<1||$qty>100)throw new RuntimeException('Item atau jumlah tidak valid.');
  $q=$db->prepare("SELECT price FROM menus WHERE menu_id=? AND is_active=1 FOR UPDATE");$q->execute([$mid]);$price=$q->fetchColumn();if($price===false)throw new RuntimeException('Menu tidak ditemukan.');
  $ids[]=['id'=>$mid,'qty'=>$qty,'price'=>(float)$price];$total+=(float)$price*$qty;
 }
 $no='BRK'.date('ymdHis').random_int(100,999);$track=strtoupper(bin2hex(random_bytes(4)));
 $stockDate=$type==='PRE_ORDER'?date('Y-m-d',strtotime($scheduled)):date('Y-m-d');
 $q=$db->prepare("INSERT INTO orders(order_no,tracking_code,customer_name,order_source,order_type,table_or_seat,grab_reference,scheduled_at,stock_date,notes,status,created_by,total_amount) VALUES(?,?,?,'STAFF',?,?,?,?,?,?,'PENDING',?,?)");
 $q->execute([$no,$track,$name,$type,$table?:null,$grab?:null,$type==='PRE_ORDER'?$scheduled:null,$stockDate,trim($in['notes']??''),$_SESSION['user']['id'],$total]);$oid=(int)$db->lastInsertId();
 $d=$db->prepare("INSERT INTO order_details(order_id,menu_id,qty,unit_price) VALUES(?,?,?,?)");foreach($ids as $it)$d->execute([$oid,$it['id'],$it['qty'],$it['price']]);
 $db->commit();audit_log($db,'ORDER_CREATED','orders',$oid,['order_no'=>$no,'source'=>'STAFF','total'=>$total]);json_response(['success'=>true,'order_id'=>$oid,'order_no'=>$no,'tracking_code'=>$track,'total_amount'=>$total,'status'=>'PENDING']);
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],422);}
