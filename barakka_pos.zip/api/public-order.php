<?php
require_once __DIR__.'/../includes/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST') json_response(['success'=>false,'message'=>'Metode tidak diizinkan.'],405);csrf_require();
$in=json_decode(file_get_contents('php://input'),true)??[];
$name=trim((string)($in['customer_name']??'')); $phone=trim((string)($in['customer_phone']??''));
$type=(string)($in['order_type']??''); $items=$in['items']??[];
if($name===''||strlen($name)>150||!in_array($type,['DINE_IN','TAKE_AWAY','PRE_ORDER'],true)||!is_array($items)||!count($items)||count($items)>30) json_response(['success'=>false,'message'=>'Lengkapi nama, jenis pesanan, dan menu.'],422);
$table=trim((string)($in['table_or_seat']??'')); $scheduled=$in['scheduled_at']??null;
if($type==='DINE_IN'&&$table==='') json_response(['success'=>false,'message'=>'Nomor meja wajib diisi.'],422);
if($type==='PRE_ORDER'&&(!$scheduled||strtotime((string)$scheduled)===false||strtotime((string)$scheduled)<=time())) json_response(['success'=>false,'message'=>'Jadwal Pre-Order harus di masa depan.'],422);
try {
 $db->beginTransaction(); $clean=[]; $total=0;
 foreach($items as $it){$mid=filter_var($it['menu_id']??null,FILTER_VALIDATE_INT);$qty=filter_var($it['qty']??null,FILTER_VALIDATE_INT);if(!$mid||!$qty||$qty<1||$qty>100)throw new RuntimeException('Jumlah menu tidak valid.');
  $q=$db->prepare('SELECT menu_id,price FROM menus WHERE menu_id=? AND is_active=1 FOR UPDATE');$q->execute([$mid]);$m=$q->fetch();if(!$m)throw new RuntimeException('Menu tidak tersedia.');$clean[]=['id'=>$mid,'qty'=>$qty,'price'=>(float)$m['price']];$total+=(float)$m['price']*$qty;
 }
 $no='BRK'.date('ymdHis').random_int(100,999);$track=strtoupper(bin2hex(random_bytes(4)));
 $stockDate=$type==='PRE_ORDER'?date('Y-m-d',strtotime((string)$scheduled)):date('Y-m-d');
 $q=$db->prepare("INSERT INTO orders(order_no,tracking_code,customer_name,customer_phone,order_source,order_type,table_or_seat,scheduled_at,stock_date,notes,status,created_by,total_amount) VALUES(?,?,?,?,'PUBLIC',?,?,?,?,?,'PENDING',NULL,?)");
 $q->execute([$no,$track,$name,$phone?:null,$type,$table?:null,$type==='PRE_ORDER'?$scheduled:null,$stockDate,trim((string)($in['notes']??'')),$total]);$oid=(int)$db->lastInsertId();
 $d=$db->prepare('INSERT INTO order_details(order_id,menu_id,qty,unit_price) VALUES(?,?,?,?)');foreach($clean as $it)$d->execute([$oid,$it['id'],$it['qty'],$it['price']]);
 $db->commit();audit_log($db,'ORDER_CREATED_PUBLIC','orders',$oid,['order_no'=>$no,'total'=>$total]);json_response(['success'=>true,'order_no'=>$no,'tracking_code'=>$track,'total_amount'=>$total,'track_url'=>'track.php?order='.urlencode($no).'&code='.urlencode($track)]);
} catch(Throwable $e){if($db->inTransaction())$db->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],422);}
