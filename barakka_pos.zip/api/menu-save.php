<?php
require_once __DIR__.'/../includes/bootstrap.php';require_role(['OWNER']);
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['success'=>false,'message'=>'Metode tidak diizinkan.'],405);
csrf_require();
$id=(int)($_POST['menu_id']??0);$name=trim((string)($_POST['menu_name']??''));$cat=trim((string)($_POST['category']??'Makanan'));$unit=trim((string)($_POST['unit_name']??'porsi'));$price=filter_var($_POST['price']??null,FILTER_VALIDATE_FLOAT);$desc=trim((string)($_POST['description']??''));
if($name===''||mb_strlen($name)>150||$price===false||$price<0||$cat===''||$unit==='')json_response(['success'=>false,'message'=>'Nama menu, kategori, satuan, dan harga wajib valid.'],422);
$imagePath=null;$oldPath=null;
try{
 if($id){$q=$db->prepare('SELECT image_path FROM menus WHERE menu_id=?');$q->execute([$id]);$oldPath=$q->fetchColumn();if($oldPath===false)json_response(['success'=>false,'message'=>'Menu tidak ditemukan.'],404);}
 if(isset($_FILES['menu_image'])&&($_FILES['menu_image']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){$f=$_FILES['menu_image'];if($f['error']!==UPLOAD_ERR_OK)throw new RuntimeException('Upload foto gagal.');if($f['size']>3*1024*1024)throw new RuntimeException('Ukuran foto maksimal 3 MB.');$fi=new finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;if(!$ext)throw new RuntimeException('Format foto harus JPG, PNG, atau WEBP.');$info=getimagesize($f['tmp_name']);if(!$info||$info[0]>6000||$info[1]>6000)throw new RuntimeException('Dimensi foto tidak valid atau terlalu besar.');$dir=__DIR__.'/../uploads/menu';if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Folder upload tidak dapat dibuat.');$file='menu_'.bin2hex(random_bytes(16)).'.'.$ext;if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$file))throw new RuntimeException('Gagal menyimpan foto.');$imagePath='uploads/menu/'.$file;}
 if($id){if($imagePath){$q=$db->prepare('UPDATE menus SET menu_name=?,category=?,unit_name=?,price=?,description=?,image_path=? WHERE menu_id=?');$q->execute([$name,$cat,$unit,$price,$desc,$imagePath,$id]);}else{$q=$db->prepare('UPDATE menus SET menu_name=?,category=?,unit_name=?,price=?,description=? WHERE menu_id=?');$q->execute([$name,$cat,$unit,$price,$desc,$id]);}}
 else{$q=$db->prepare('INSERT INTO menus(menu_name,category,unit_name,price,description,image_path) VALUES(?,?,?,?,?,?)');$q->execute([$name,$cat,$unit,$price,$desc,$imagePath]);$id=(int)$db->lastInsertId();}
 audit_log($db,'MENU_SAVE','menus',$id,['menu_name'=>$name,'image_updated'=>(bool)$imagePath]);
 if($imagePath&&$oldPath&&str_starts_with($oldPath,'uploads/menu/')){@unlink(__DIR__.'/../'.$oldPath);}
 json_response(['success'=>true,'menu_id'=>$id,'image_path'=>$imagePath]);
}catch(Throwable $e){if($imagePath&&is_file(__DIR__.'/../'.$imagePath))@unlink(__DIR__.'/../'.$imagePath);json_response(['success'=>false,'message'=>$e->getMessage()],422);}
