USE barakka_pos;

-- Tambahkan estimasi waktu pengerjaan tanpa menghapus data pesanan.
SET @has_estimated_minutes = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'orders'
    AND COLUMN_NAME = 'estimated_minutes'
);
SET @ddl = IF(
  @has_estimated_minutes = 0,
  'ALTER TABLE orders ADD COLUMN estimated_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 15 AFTER completed_at',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Pesanan PREPARING lama tetap memakai started_at yang sudah tersimpan.
-- Estimasi default 15 menit; jika sudah melewati target, KDS menampilkan Terlambat.
