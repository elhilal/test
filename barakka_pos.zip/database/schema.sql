CREATE DATABASE IF NOT EXISTS barakka_pos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barakka_pos;

CREATE TABLE users (
 user_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, username VARCHAR(60) NOT NULL UNIQUE,
 full_name VARCHAR(150) NOT NULL, password_hash VARCHAR(255) NOT NULL,
 role ENUM('OWNER','KASIR','CHEF','KARYAWAN') NOT NULL, is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE menus (
 menu_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, menu_name VARCHAR(150) NOT NULL,
 description VARCHAR(500) NULL, category VARCHAR(80) NOT NULL DEFAULT 'Makanan',
 unit_name VARCHAR(40) NOT NULL DEFAULT 'porsi', price DECIMAL(14,2) NOT NULL,
 image_path VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX ix_menu_active(is_active,category)
) ENGINE=InnoDB;
CREATE TABLE daily_stocks (
 stock_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, menu_id BIGINT UNSIGNED NOT NULL,
 stock_date DATE NOT NULL, initial_qty INT UNSIGNED NOT NULL, available_qty INT UNSIGNED NOT NULL,
 reserved_qty INT UNSIGNED NOT NULL DEFAULT 0, used_qty INT UNSIGNED NOT NULL DEFAULT 0,
 UNIQUE KEY uq_daily_menu(menu_id,stock_date), CONSTRAINT fk_stock_menu FOREIGN KEY(menu_id) REFERENCES menus(menu_id),
 CONSTRAINT chk_stock_total CHECK(initial_qty=available_qty+reserved_qty+used_qty)
) ENGINE=InnoDB;
CREATE TABLE orders (
 order_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_no VARCHAR(32) NOT NULL UNIQUE,
 tracking_code CHAR(8) NOT NULL UNIQUE, customer_name VARCHAR(150) NOT NULL, customer_phone VARCHAR(30) NULL,
 order_source ENUM('PUBLIC','STAFF') NOT NULL DEFAULT 'STAFF',
 order_type ENUM('DINE_IN','TAKE_AWAY','GRAB','PRE_ORDER') NOT NULL,
 table_or_seat VARCHAR(60) NULL, grab_reference VARCHAR(100) NULL, scheduled_at DATETIME NULL,
 stock_date DATE NOT NULL, notes TEXT NULL,
 status ENUM('PENDING','RESERVED','PREPARING','COMPLETED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
 reservation_state ENUM('NONE','HELD','CONSUMED','RELEASED') NOT NULL DEFAULT 'NONE',
 created_by BIGINT UNSIGNED NULL, accepted_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, started_at DATETIME NULL, completed_at DATETIME NULL,
 estimated_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 15,
 total_amount DECIMAL(14,2) NOT NULL DEFAULT 0, INDEX ix_orders_created(created_at), INDEX ix_orders_status(status),
 INDEX ix_orders_schedule(scheduled_at), CONSTRAINT fk_order_creator FOREIGN KEY(created_by) REFERENCES users(user_id),
 CONSTRAINT fk_order_acceptor FOREIGN KEY(accepted_by) REFERENCES users(user_id)
) ENGINE=InnoDB;
CREATE TABLE order_details (
 detail_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL,
 menu_id BIGINT UNSIGNED NOT NULL, qty INT UNSIGNED NOT NULL, unit_price DECIMAL(14,2) NOT NULL,
 line_total DECIMAL(14,2) GENERATED ALWAYS AS(qty*unit_price) STORED,
 CONSTRAINT fk_detail_order FOREIGN KEY(order_id) REFERENCES orders(order_id),
 CONSTRAINT fk_detail_menu FOREIGN KEY(menu_id) REFERENCES menus(menu_id), CHECK(qty>0)
) ENGINE=InnoDB;
CREATE TABLE payments (
 payment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL,
 payment_method ENUM('CASH','QRIS','DEBIT','CREDIT','TRANSFER','GRAB') NOT NULL,
 amount DECIMAL(14,2) NOT NULL, payment_status ENUM('UNPAID','PAID','REFUNDED') NOT NULL DEFAULT 'UNPAID',
 reference_no VARCHAR(100) NULL, paid_at DATETIME NULL, received_by BIGINT UNSIGNED NULL,
 INDEX ix_payment_paid(paid_at,payment_status), CONSTRAINT fk_payment_order FOREIGN KEY(order_id) REFERENCES orders(order_id),
 CONSTRAINT fk_payment_user FOREIGN KEY(received_by) REFERENCES users(user_id)
) ENGINE=InnoDB;
CREATE TABLE stock_movements (
 movement_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, stock_id BIGINT UNSIGNED NOT NULL,
 order_id BIGINT UNSIGNED NULL, movement_type ENUM('OPENING','RESERVE','CONSUME','RELEASE','ADJUSTMENT') NOT NULL,
 qty INT UNSIGNED NOT NULL, actor_user_id BIGINT UNSIGNED NULL, note VARCHAR(255) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX ix_movement_order(order_id),
 CONSTRAINT fk_move_stock FOREIGN KEY(stock_id) REFERENCES daily_stocks(stock_id),
 CONSTRAINT fk_move_order FOREIGN KEY(order_id) REFERENCES orders(order_id),
 CONSTRAINT fk_move_user FOREIGN KEY(actor_user_id) REFERENCES users(user_id)
) ENGINE=InnoDB;
CREATE TABLE order_status_logs (
 log_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL,
 old_status VARCHAR(20) NULL, new_status VARCHAR(20) NOT NULL, actor_user_id BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_log_order FOREIGN KEY(order_id) REFERENCES orders(order_id),
 CONSTRAINT fk_log_user FOREIGN KEY(actor_user_id) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
 audit_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(60) NOT NULL,
 entity VARCHAR(60) NOT NULL,
 entity_id BIGINT UNSIGNED NULL,
 details JSON NULL,
 ip_address VARCHAR(45) NULL,
 user_agent VARCHAR(255) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX ix_audit_created(created_at), INDEX ix_audit_entity(entity,entity_id),
 CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO menus(menu_name,description,category,unit_name,price) VALUES
('Nasi Goreng','Nasi goreng khas BARAKKA','Makanan','porsi',25000),
('Es Teh','Es teh manis segar','Minuman','gelas',7000),
('Mie Goreng','Mie goreng spesial','Makanan','porsi',22000),
('Ayam Bakar','Ayam bakar bumbu pilihan','Makanan','porsi',30000);
