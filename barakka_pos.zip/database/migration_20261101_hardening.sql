USE barakka_pos;

-- Compatibility fix: some existing BARAKKA databases may not yet have
-- category/image_path although current PHP pages use both columns.
DELIMITER $$
DROP PROCEDURE IF EXISTS barakka_upgrade_menu_columns$$
CREATE PROCEDURE barakka_upgrade_menu_columns()
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'menus' AND COLUMN_NAME = 'category'
  ) THEN
    ALTER TABLE menus ADD COLUMN category VARCHAR(80) NOT NULL DEFAULT 'Makanan' AFTER description;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'menus' AND COLUMN_NAME = 'image_path'
  ) THEN
    ALTER TABLE menus ADD COLUMN image_path VARCHAR(255) NULL AFTER price;
  END IF;
END$$
CALL barakka_upgrade_menu_columns()$$
DROP PROCEDURE barakka_upgrade_menu_columns$$
DELIMITER ;

CREATE TABLE IF NOT EXISTS audit_logs (
 audit_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(60) NOT NULL,
 entity VARCHAR(60) NOT NULL,
 entity_id BIGINT UNSIGNED NULL,
 details JSON NULL,
 ip_address VARCHAR(45) NULL,
 user_agent VARCHAR(255) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX ix_audit_created(created_at), INDEX ix_audit_entity(entity,entity_id),
 CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;
