<?php
require_once __DIR__.'/includes/bootstrap.php';
if(!empty($_SESSION['user'])){header('Location: index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_require();
 $q=$db->prepare("SELECT user_id,full_name,password_hash,role,is_active FROM users WHERE username=? LIMIT 1");$q->execute([trim($_POST['username']??'')]);$u=$q->fetch();
 if($u&&(int)$u['is_active']===1&&password_verify($_POST['password']??'',$u['password_hash'])){
  session_regenerate_id(true);$_SESSION['user']=['id'=>(int)$u['user_id'],'name'=>$u['full_name'],'role'=>$u['role']];audit_log($db,'LOGIN_SUCCESS','users',(int)$u['user_id']);header('Location: index.php');exit;
 }$error='Nama pengguna atau kata sandi tidak sesuai. Silakan periksa kembali.';
}
$roleLabels=['OWNER'=>'Pemilik','KASIR'=>'Kasir','CHEF'=>'Koki','KARYAWAN'=>'Karyawan'];
?>
<!doctype html>
<html lang="id">
<head><meta name="csrf-token" content="<?=e(csrf_token())?>">
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#292524"><link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="assets/icons/barakka.svg" type="image/svg+xml">
<title>Masuk | BARAKKA POS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="login-bg">
<main class="container min-vh-100 d-flex align-items-center justify-content-center py-4">
<div class="login-card row g-0 overflow-hidden">
 <div class="col-lg-6 login-hero p-5 text-white d-flex flex-column justify-content-between">
  <div>
   <div class="brand-mark"><span> B </span></div>
   <div class="eyebrow text-warning mt-4">SISTEM KASIR & PEMESANAN</div>
   <h1 class="display-5 fw-bold mt-2">BARAKKA</h1>
   <h2 class="h4 fw-semibold text-warning">Dapur Rasa</h2>
   <p class="lead mt-3">Rasa Nikmat, Harga Bersahabat.</p>
   <p class="text-white-50">Kelola pesanan, stok, dapur, dan penjualan dalam satu sistem.</p>
  </div>
  <small class="opacity-75">BARAKKA POS · Sistem Pemesanan dan Kasir</small>
 </div>
 <div class="col-lg-6 bg-white p-4 p-md-5 d-flex flex-column justify-content-center">
  <div class="eyebrow">SELAMAT DATANG</div>
  <h2 class="fw-bold mt-2">Masuk ke BARAKKA POS</h2>
  <p class="text-secondary mb-4">Masukkan akun operasional Anda untuk melanjutkan.</p>
  <?php if($error):?><div class="alert alert-danger" role="alert"><?=e($error)?></div><?php endif;?>
  <form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
   <label class="form-label fw-semibold">Nama pengguna</label>
   <input class="form-control form-control-lg mb-3" name="username" required autocomplete="username" placeholder="Masukkan nama pengguna">
   <label class="form-label fw-semibold">Kata sandi</label>
   <input class="form-control form-control-lg mb-4" type="password" name="password" required autocomplete="current-password" placeholder="Masukkan kata sandi">
   <button class="btn btn-brand btn-lg w-100" type="submit">MASUK SEKARANG <span aria-hidden="true">→</span></button>
  </form>
  <small class="text-secondary d-block mt-4">Akses tersedia untuk Pemilik, Kasir, Koki, dan Karyawan.</small>
 </div>
</div>
</main>
<script>if("serviceWorker" in navigator && location.protocol.startsWith("http")){navigator.serviceWorker.register("sw.js").catch(()=>{});}</script></body>
</html>
