# BARAKKA POS — Dapur Rasa

Sistem POS dan pemesanan makanan berbasis PHP Native OOP, PDO, MySQL 8, Bootstrap 5, dan JavaScript.

## Modul
- Pelanggan: halaman menu publik, pemesanan via QR Code/link website, dan pelacakan dengan nomor order + kode pelacakan.
- Internal: login role OWNER, KASIR, CHEF, KARYAWAN; dashboard, antrean dapur, timer, persetujuan order, stok harian, pembayaran, laporan, dan CSV.
- Jenis order: Dine-In, Take Away, Grab (input internal), dan Pre-Order.

## Instalasi XAMPP (Windows)
1. Ekstrak folder `BARAKKA_POS` ke `C:\xampp\htdocs\BARAKKA_POS`.
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka `http://localhost/phpmyadmin`, pilih Import, lalu import `database/schema.sql`. Database `barakka_pos` akan dibuat otomatis.
4. Periksa `config/database.php` (default host 127.0.0.1, user root, password kosong). Sesuaikan bila konfigurasi MySQL berbeda.
5. Buat akun Owner dengan membuka `http://localhost/BARAKKA_POS/scripts/create_user.php`. Setelah berhasil, hapus atau nonaktifkan file tersebut.
6. Login melalui `http://localhost/BARAKKA_POS/login.php`.
7. Halaman pelanggan: `http://localhost/BARAKKA_POS/customer.php`. Halaman pelacakan: `http://localhost/BARAKKA_POS/track.php`.

## QR Code meja
QR Code dapat dibuat dari URL seperti `https://domain-anda/customer.php?meja=01`. Gunakan generator QR Code tepercaya atau fitur QR pada aplikasi internal. Jangan gunakan URL localhost untuk pelanggan di luar komputer server.

## Aturan stok
- Pesanan pelanggan dan Pre-Order berstatus PENDING dan belum mengurangi stok.
- Owner/Kasir menyetujui pesanan setelah sistem memeriksa stok tanggal layanan.
- Order langsung mengubah stok tersedia menjadi terpakai saat disetujui.
- Pre-Order menahan stok (reserved) sampai Chef memulai proses.
- Pembatalan Pre-Order yang sudah di-reserve mengembalikan stok.

## Catatan penting sebelum produksi
- Jalankan di HTTPS untuk akses internet.
- Batasi akses database, backup rutin, dan hapus/nonaktifkan `scripts/create_user.php` setelah membuat Owner.
- Tambahkan CSRF protection, rate limiting, kebijakan privasi, dan integrasi payment gateway sebelum menerima transaksi online sungguhan.
- QRIS pada versi ini dicatat manual; belum terhubung payment gateway. Grab juga dicatat manual, bukan integrasi API Grab.
- CSV tersedia; XLSX, cetak struk thermal, dan notifikasi WhatsApp memerlukan pengembangan lanjutan.

## Identitas
BARAKKA — Dapur Rasa | Rasa Nikmat, Harga Bersahabat.


## Identitas visual BARAKKA Modern
- Golden Yellow: `#F5A900`
- Deep Red: `#C91F37`
- Warm Cream: `#FFF8ED`
- Charcoal: `#292524`
- Soft Gray: `#E8E2D9`

Tema diterapkan melalui `assets/css/app.css`, metadata PWA, dan ikon aplikasi. Jika aplikasi sudah pernah dibuka, tutup lalu buka kembali atau refresh untuk memuat cache tema terbaru.


## Pembaruan fitur operasional
1. Jalankan `database/migration_20261101_hardening.sql` pada database lama untuk membuat tabel audit log dan kompatibilitas kolom menu.
2. Jalankan `database/migration_20261105_kitchen_timer.sql` untuk menambahkan estimasi waktu pengerjaan Koki. Jangan import ulang schema awal pada database yang sudah berisi data.
2. Foto menu: buka Master Menu, pilih foto JPG/PNG/WEBP maksimal 3 MB. Folder `uploads/menu` dibuat otomatis dan harus dapat ditulis oleh Apache. Pastikan folder `uploads` tidak mengizinkan eksekusi PHP.
3. Kitchen Display: buka `kitchen.php` menggunakan akun OWNER atau CHEF. Tiket dapur dapat dicetak dari tombol pada setiap pesanan.
4. Ekspor Excel: tombol ekspor menghasilkan XLSX. Jika muncul pesan ZipArchive, aktifkan `extension=zip` pada php.ini XAMPP dan restart Apache.
5. Keamanan: endpoint POST memakai token CSRF. Muat ulang halaman setelah login atau setelah sesi berakhir.
6. Audit log: aktivitas order, pembayaran, dan penyimpanan menu tercatat pada tabel `audit_logs`.
7. Printer thermal: cetak tiket memakai dialog print browser; pilih printer thermal dan ukuran kertas yang sesuai (umumnya 58mm atau 80mm).

## Checklist keamanan folder upload
- Jangan menyimpan file PHP dalam `uploads/menu`.
- Nonaktifkan directory listing.
- Pada Apache, buat `.htaccess` dalam folder `uploads` untuk menolak eksekusi skrip.

8. Audit aktivitas Owner dapat dilihat melalui `audit.php`.
9. Struk pembayaran dapat dicetak melalui `receipt.php?id=ID_ORDER` oleh Owner/Kasir.
10. Tiket dapur melalui `kitchen-ticket.php?id=ID_ORDER` oleh Owner/Kasir/Chef.

### Catatan konfigurasi PHP untuk upload foto dan Excel
- Pada XAMPP Control Panel, klik Config pada Apache lalu buka `PHP (php.ini)`.
- Pastikan `file_uploads=On`, `upload_max_filesize=4M`, dan `post_max_size=8M`.
- Aktifkan `extension=fileinfo` dan `extension=zip` (hapus tanda `;` di awal baris jika ada), lalu restart Apache.
- Jika ekstensi `zip` tidak tersedia, ekspor XLSX akan memberi pesan agar ekstensi tersebut diaktifkan. Tidak perlu memasang Composer.

### Pembaruan database yang sudah berisi data
- Backup database `barakka_pos` terlebih dahulu melalui phpMyAdmin.
- Jalankan `database/migration_20261101_hardening.sql` melalui tab SQL phpMyAdmin.
- Migrasi ini menambahkan `category`/`image_path` jika belum ada serta tabel `audit_logs`. Tidak menghapus transaksi, menu, atau pengguna.

## Tampilan berdasarkan peran (pembaruan UI BARAKKA Modern)

- **Pelanggan:** `customer.php` menampilkan katalog menu bergambar, keranjang, checkout, dan tautan tracking.
- **Koki:** setelah login, role `CHEF` diarahkan langsung ke `kitchen.php` untuk melihat antrean, memulai, dan menyelesaikan pesanan.
- **Kasir:** dashboard `index.php` menampilkan ringkasan, daftar pesanan, stok, akses QR meja, serta laporan.
- **Karyawan:** dashboard ringkas dengan akses utama untuk membuat pesanan; tidak ditampilkan menu administrasi.
- **Pemilik:** dashboard operasional, laporan, master menu, stok, QR, pengguna, dan audit log.

Tema UI menggunakan Golden Yellow `#F5A900`, Deep Red `#C91F37`, Warm Cream `#FFF8ED`, Charcoal `#292524`, dan Soft Gray `#E8E2D9`. Tombol aksi utama menggunakan Deep Red; warna kuning digunakan sebagai aksen dan highlight.

Pembaruan UI ini tidak memerlukan migrasi database tambahan. Fitur backend tetap mengikuti API dan schema pada paket ini.

### Pembaruan Kitchen Display (5 November 2026)
- Untuk database lama, backup terlebih dahulu lalu jalankan `database/migration_20261105_kitchen_timer.sql`.
- Setelah migration, approval order mengubah status menjadi RESERVED dan stok ditahan. Timer belum berjalan sampai Koki menekan Mulai Memasak.
- Koki memilih estimasi pengerjaan 5, 10, 15, 20, 30, 45, atau 60 menit (API menerima 1–180 menit).
- Pesanan PRE_ORDER tetap tidak dapat dimulai sebelum waktu jadwalnya.
